<h1>Bank Portal</h1>
<p>This is a bank Management portal developed using HTML CSS Bootstrap and Javascript.</p>
<p>Chart.js is also utilized to develop a chart.</p>
<h1>Features</h1>
<p>The user can signup to create an account.</p>
<p>User can the sign in to his account.</p>
<p>User can deposit and withdraw cash and its balance is maintained and displayed on UI.</p>
<p>There are other features added which include Newsletter FAQ etc.</p>
